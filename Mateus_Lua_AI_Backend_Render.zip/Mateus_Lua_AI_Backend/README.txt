MATEUS LUA AI - BACKEND

No Render: Build Command = npm install; Start Command = npm start.
Environment Variables: OPENAI_API_KEY = sua chave; OPENAI_MODEL = gpt-6-luna (opcional).
Depois do deploy, no V7 use: https://SEU-SERVICO.onrender.com/api/generate
O teste usa: https://SEU-SERVICO.onrender.com/health
Nunca coloque a chave no HTML ou envie a chave para outras pessoas.
